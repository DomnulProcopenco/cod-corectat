someNumber = 10

if someNumber < 0:
    print("Bellow zerro")
elif someNumber == 0:
    print("zerro")
else:
    print("Over zerro")